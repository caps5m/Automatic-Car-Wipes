# Automatic-Car-Wipes
Pretty obvious, just an automatic car wipe system for you FiveM server!
